import seaborn as sns
import matplotlib.pyplot as plt

# Sample Data
data = {'Category': ['A', 'A', 'B', 'B', 'C', 'C'],
        'Value': [5, 6, 7, 8, 5, 7]}
import pandas as pd
df = pd.DataFrame(data)

sns.swarmplot(x='Category', y='Value', data=df)
plt.show()