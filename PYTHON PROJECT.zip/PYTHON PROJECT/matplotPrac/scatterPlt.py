import matplotlib.pyplot as plt
import numpy as np
a=np.array([1,2,4,5])
b=np.array([6,7,8,9])
plt.scatter(a,b,color='pink')
a=np.array([11,12,14,15])
b=np.array([26,72,28,29])
plt.scatter(a,b,color='green')
plt.show()