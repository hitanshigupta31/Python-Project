import matplotlib.pyplot as plt
fig = plt.figure()
ax = plt.axes([0.1, 0.1, 0.8, 0.8])  # [left, bottom, width, height]
plt.show()