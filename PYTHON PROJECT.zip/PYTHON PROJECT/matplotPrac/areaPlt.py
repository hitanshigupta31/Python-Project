import matplotlib.pyplot as plt
days=[1,2,3,4,5]
sleeping=[7,8,9,10,11]
eating=[8,8,7,2,3]
plt.plot([],[],color='m',label='sleeping',linewidth=5)
plt.plot([],[],color='c',label='eating',linewidth=5)
plt.stackplot(days,sleeping,eating,colors=['m','c'])
plt.xlabel('x')
plt.ylabel('y')
plt.title('Stack plot')
plt.legend()
plt.show()