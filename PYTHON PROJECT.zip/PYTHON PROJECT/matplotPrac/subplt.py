import matplotlib.pyplot as plt
import numpy as np
a=np.array([0,1,2,3])
b=np.array([3,8,1,10])
plt.subplot(1,2,1)
plt.plot(a,b)

a=np.array([0,1,2,3])
b=np.array([10,20,30,40])
plt.subplot(1,2,2)
plt.plot(a,b)
plt.show()