import matplotlib.pyplot as plt
import numpy as np

# Creating the Figure instance
fig = plt.figure(figsize=[7, 3], facecolor='lightgreen', layout='constrained')

# Adding a title to the Figure
fig.suptitle('Figure')

# Adding a subplot (Axes) to the Figure
ax = fig.add_subplot()

# Setting a title for the subplot
ax.set_title('Axes', loc='left', fontstyle='oblique', fontsize='medium')

# Showing the plot
plt.show()