import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

data = {'Category': ['A','A','B','B','C','C'],
        'Value': [5,6,7,8,5,7]}
df = pd.DataFrame(data)

sns.violinplot(x='Category', y='Value', data=df)
plt.show()