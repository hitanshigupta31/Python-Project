#QUESTION 1
import matplotlib.pyplot as plt
import numpy as np
"""

students = ['Alice', 'Bob', 'Charlie', 'David', 'Eva']
scores = [85, 90, 78, 88, 95]
plt.bar(students, scores, color='skyblue')
plt.xlabel('Students')
plt.ylabel('Scores')
plt.title('Student Scores in Mathematics')
plt.show()
"""

#PIE CHART
"""
activities = ['Sleeping', 'Eating', 'Working', 'Studying', 'Exercising']
hours = [8, 2, 8, 4, 2]

plt.pie(hours, labels=activities, autopct='%1.1f%%', startangle=90)
plt.title('Daily Time Distribution')

plt.axis('equal') 
plt.show()
"""
#QUESTION 3

x = np.linspace(-10, 10, 100)  
y = x ** 2

plt.plot(x, y, color='green', linewidth=2)

plt.xlabel('x-axis')
plt.ylabel('y-axis')
plt.title('Graph of y = x²')

plt.grid(True)
plt.show()